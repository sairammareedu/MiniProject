import streamlit as st
import pandas as pd
import warnings
from deep_translator import GoogleTranslator
from streamlit_option_menu import option_menu
from sklearn.model_selection import train_test_split
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.decomposition import PCA
from sklearn.metrics import accuracy_score

# Suppress warnings
warnings.filterwarnings("ignore")

# Load and preprocess data
data = pd.read_csv("fetal_health.csv")
data = data.dropna(axis=0, how='any')
data2 = pd.read_csv("Maternal Health Risk Data Set.csv")
data2 = data2.dropna(axis=0, how='any')

# Split data for maternal health model
y = data2['RiskLevel']
x = data2.drop('RiskLevel', axis=1)
x_train, x_test, y_train, y_test = train_test_split(x, y, random_state=0, test_size=0.2)

# Split data for fetal health model
y2 = data['fetal_health']
x2 = data.drop('fetal_health', axis=1)
x2_train, x2_test, y2_train, y2_test = train_test_split(x2, y2, random_state=0, test_size=0.2)

# Train maternal health model
maternal_model = GradientBoostingClassifier()
maternal_model.fit(x_train, y_train)

# Train fetal health model
fetal_model = GradientBoostingClassifier()
fetal_model.fit(x2_train, y2_train)

maternal_predictions = maternal_model.predict(x_test)
maternal_accuracy = accuracy_score(y_test, maternal_predictions)
print(f"Maternal Health Model Accuracy: {maternal_accuracy:.2f}")

# Calculate and print accuracy for fetal health model
fetal_predictions = fetal_model.predict(x2_test)
fetal_accuracy = accuracy_score(y2_test, fetal_predictions)
print(f"Fetal Health Model Accuracy: {fetal_accuracy:.2f}")

# PCA for fetal health
pcaf = PCA(n_components=10)
pcaf.fit(x2)

# Get the principal components
components = pcaf.components_

# Get the column names
column_names = x2.columns

# Find the column with the highest absolute value in each component
most_influential_columns_for_fetal_health = []
for component in components:
    index = component.argmax()  # Get the index of the highest absolute value
    most_influential_columns_for_fetal_health.append(column_names[index])

# PCA for maternal health
pcam = PCA(n_components=4)
pcam.fit(x)

# Get the principal components
components = pcam.components_

# Get the column names
column_names = x.columns

# Find the column with the highest absolute value in each component
most_influential_columns_for_maternal_health = []
for component in components:
    index = component.argmax()  # Get the index of the highest absolute value
    most_influential_columns_for_maternal_health.append(column_names[index])

# --- Define the translation function ---
def translate_text(text, target_language):
    try:
        translated_text = GoogleTranslator(source='en', target=target_language).translate(text)
        return translated_text
    except Exception as e:
        st.warning(f"Translation error: {e}. Displaying in English.")
        return text

# List of supported languages including Indian languages
LANGUAGES = {
    "English": "en",
    "Spanish": "es",
    "French": "fr",
    "German": "de",
    "Chinese": "zh",
    "Hindi": "hi",
    "Bengali": "bn",
    "Tamil": "ta",
    "Telugu": "te",
    "Gujarati": "gu",
    "Marathi": "mr",
    "Punjabi": "pa",
    "Kannada": "kn",
    "Malayalam": "ml",
    "Odia": "or",
    "Urdu": "ur",
    "Nepali": "ne"
}

# Sidebar for language selection
st.sidebar.title("Language Selection")
language_name = st.sidebar.selectbox("Choose your language", list(LANGUAGES.keys()))
language_code = LANGUAGES[language_name]

# Sidebar menu
with st.sidebar:
    selected = option_menu('Health Check', 
                           ['About us', 'Pregnancy Risk Prediction', 'Fetal Health Prediction', 'Suggestions', 'More..'],
                           icons=['chat-square-text', 'hospital', 'capsule-pill', 'clipboard-data'], 
                           default_index=0)

# --- Translate the text for the interface ---
title = translate_text("About Us", language_code)
about_text = translate_text(
    "At Health Checkers, we aim to revolutionize healthcare by providing predictive analysis for maternal and fetal health.", 
    language_code
)
pregnancy_risk_title = translate_text("Pregnancy Risk Prediction", language_code)
pregnancy_risk_text = translate_text(
    "This feature uses advanced algorithms to assess risks during pregnancy, analyzing parameters like age, blood pressure, and more.", 
    language_code
)
fetal_health_title = translate_text("Fetal Health Prediction", language_code)
fetal_health_text = translate_text(
    "This system assesses fetal health status by analyzing various factors, providing insights into the baby's well-being.", 
    language_code
)

# Suggestions for Maternal and Fetal Health
suggestions = {
    "Maternal Health": {
        "Low Risk": [
            "Keep up with scheduled prenatal appointments.",
            "Maintain a balanced diet rich in essential nutrients.",
            "Stay physically active with exercises suitable for pregnant women."
        ],
        "Medium Risk": [
            "Consult your healthcare provider if you notice any unusual symptoms.",
            "Follow your healthcare provider's recommendations closely.",
            "Monitor for any signs of preterm labor, such as regular contractions."
        ],
        "High Risk": [
            "Seek immediate medical attention in case of emergencies.",
            "Follow your healthcare provider's advice rigorously.",
            "Prepare for closer monitoring and possible interventions if indicated."
        ]
    },
    "Fetal Health": {
        "Normal Prediction": [
            "Ensure regular prenatal care to monitor fetal growth.",
            "Maintain a healthy lifestyle, avoiding harmful substances.",
            "Take prenatal vitamins as prescribed."
        ],
        "Suspect Prediction": [
            "Contact your healthcare provider if you have concerns about fetal movement.",
            "Follow recommendations for fetal monitoring, such as kick counts.",
            "Monitor for any signs of preterm labor or fetal distress."
        ],
        "Pathological Prediction": [
            "Discuss options with your healthcare provider if complications are detected.",
            "Follow advice on specialized testing if recommended.",
            "Prepare for potential interventions to optimize fetal health outcomes."
        ]
    }
}

# --- Display content based on selected menu item ---
if selected == 'Pregnancy Risk Prediction':
    st.title(translate_text("Pregnancy Risk Prediction", language_code))
    
    # Collect only inputs for the most influential columns for maternal health
    input_features = {}
    for col in most_influential_columns_for_maternal_health:
        input_features[col] = st.text_input(f'Enter {col}', key=f"maternal_{col}")
    
    if st.button('Predict Pregnancy Risk'):
        try:
            # Convert input to list for model prediction
            input_values = [float(input_features[col]) for col in most_influential_columns_for_maternal_health]
            predicted_risk = maternal_model.predict([input_values])[0]
            
            # Display the risk level and suggestions
            if predicted_risk == 0:
                risk_level = "Low Risk"
                st.markdown('<p style="font-weight: bold; font-size: 20px; color: green;">Low Risk</p>', unsafe_allow_html=True)
            elif predicted_risk == 1:
                risk_level = "Medium Risk"
                st.markdown('<p style="font-weight: bold; font-size: 20px; color: orange;">Medium Risk</p>', unsafe_allow_html=True)
            elif predicted_risk == 2:
                risk_level = "High Risk"
                st.markdown('<p style="font-weight: bold; font-size: 20px; color: red;">High Risk</p>', unsafe_allow_html=True)
            
            # Display translated suggestions
            st.subheader(translate_text("Suggestions:", language_code))
            for suggestion in suggestions["Maternal Health"][risk_level]:
                st.write(f"- {translate_text(suggestion, language_code)}")
                
        except Exception as e:
            st.warning(f"Error in prediction: {e}")

elif selected == 'Fetal Health Prediction':
    st.title(translate_text("Fetal Health Prediction", language_code))
    
    # Collect only inputs for the most influential columns for fetal health
    fetal_input_features = {}
    for col in most_influential_columns_for_fetal_health:
        fetal_input_features[col] = st.text_input(f'Enter {col}', key=f"fetal_{col}")
    
    if st.button('Predict Fetal Health'):
        try:
            # Convert input to list for model prediction
            fetal_input_values = [float(fetal_input_features[col]) for col in most_influential_columns_for_fetal_health]
            predicted_health = fetal_model.predict([fetal_input_values])[0]
            
            # Display health status and suggestions
            if predicted_health == 1:
                health_status = "Normal Prediction"
                st.markdown('<p style="font-weight: bold; font-size: 20px; color: green;">Normal</p>', unsafe_allow_html=True)
            elif predicted_health == 2:
                health_status = "Suspect Prediction"
                st.markdown('<p style="font-weight: bold; font-size: 20px; color: orange;">Suspect</p>', unsafe_allow_html=True)
            elif predicted_health == 3:
                health_status = "Pathological Prediction"
                st.markdown('<p style="font-weight: bold; font-size: 20px; color: red;">Pathological</p>', unsafe_allow_html=True)
            
            # Display translated suggestions
            st.subheader(translate_text("Suggestions:", language_code))
            for suggestion in suggestions["Fetal Health"][health_status]:
                st.write(f"- {translate_text(suggestion, language_code)}")
                
        except Exception as e:
            st.warning(f"Error in prediction: {e}")

elif selected == 'About us':
    st.title(title)
    st.write(about_text)

elif selected == 'Suggestions':
    st.header(translate_text("Suggestions for Maternal Health", language_code))
    for risk_level, tips in suggestions["Maternal Health"].items():
        st.subheader(translate_text(risk_level, language_code))
        for tip in tips:
            st.markdown(f"- {translate_text(tip, language_code)}")

    st.header(translate_text("Suggestions for Fetal Health", language_code))
    for prediction, tips in suggestions["Fetal Health"].items():
        st.subheader(translate_text(prediction, language_code))
        for tip in tips:
            st.markdown(f"- {translate_text(tip, language_code)}")

elif selected == 'More..':
    st.title(translate_text("For more information", language_code))
    st.write(translate_text("Have a look at these", language_code))
    st.markdown("""<iframe width="560" height="315" src="https://www.youtube.com/embed/0Br

import csv
from selenium import webdriver
from selenium.webdriver.common.by import By


def scrape_flipkart_products(product_name):
    driver = webdriver.Chrome()
    url = f'https://www.flipkart.com/search?q={product_name}'
    driver.get(url)
    driver.implicitly_wait(10)
    product_list = []


    product_elements = driver.find_elements(By.CLASS_NAME, '_2kHMtA')


    for item in product_elements:
        product_info = {}
        try:
            product_info['name'] = item.find_element(By.CLASS_NAME, '_4rR01T').text
        except Exception as e:
            print(f"Error parsing product name: {e}")
            product_info['name'] = "N/A"


        try:
            product_info['price'] = item.find_element(By.CLASS_NAME, '_30jeq3').text
        except Exception as e:
            print(f"Error parsing product price: {e}")
            product_info['price'] = "N/A"


        try:
            product_info['rating'] = item.find_element(By.CLASS_NAME, '_3LWZlK').text
        except Exception as e:
            print(f"Error parsing product rating: {e}")
            product_info['rating'] = "N/A"


        product_list.append(product_info)


    driver.quit()
    return product_list


def save_to_csv(products, filename='products.csv'):
    keys = products[0].keys() if products else []
    with open(filename, 'w', newline='', encoding='utf-8') as file:
        writer = csv.DictWriter(file, fieldnames=keys)
        writer.writeheader()
        for product in products:
            writer.writerow(product)


product_name = input("Enter product name: ")


flipkart_products = scrape_flipkart_products(product_name)
if flipkart_products:
    for product in flipkart_products:
        print(product)
    save_to_csv(flipkart_products, filename='D:/products_iphone.csv')
    print("Data saved to products.csv")
else:
    print("No products found.")